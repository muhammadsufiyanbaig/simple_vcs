"""
SimpleVCS - A simple version control system
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from .core import SimpleVCS

__all__ = ["SimpleVCS"]
